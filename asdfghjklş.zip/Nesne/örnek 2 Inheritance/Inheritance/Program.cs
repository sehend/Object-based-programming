﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Hayvan h1 = new Hayvan();
            Hayvan h2 = new Hayvan("Kuş");
            Hayvan h3 = new Hayvan("Timsah", 655240, 2, 4, Hayvan.gender.male);
            //Hayvan h4 = new Hayvan("At", 225300);
            //Hayvan h5 = new Hayvan(120);
            //Hayvan h6 = new Hayvan(, 120);
            Surungen s1 = new Surungen();
                       
        }      
    }
}
