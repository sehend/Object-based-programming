﻿using System;

namespace Baran
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Baran çok zeki"); //C'deki printf(), C++'daki cout<<
            //Console.ReadLine(); //C'deki scnaf(), C++'daki cin>>

            //const int pii = 3;
            //const float pif = 3.14f;
            //double d = 3.5;

            //int a;
            //int A;

            //float f = 3.2f;
            //int g = (int)f;

            //1) Casting
            //2) Convert sınıfı fonksiyonları
            //3) ToString() Parse() İkilis

            //int i = 50;
            //string s = i.ToString();

            //int b = int.Parse(s);
            //double d = double.Parse(s);
            //Int64 i64 = Int64.Parse(s);

            //Int64 i64 = 400000000000;
            //Int16 i16 = (Int16)i64;
            //Console.WriteLine("{0}",i16);
            //Console.ReadLine();
        }
    }
}
