﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solide
{
    class Warplane:Aeroplane

    {

        private uint _bombcount;
        private ushort _bombcapacity;

        public uint Bombcount
        {
            get
            {
                return _bombcount;
            }

            set
            {
                _bombcount = value;
            }
        }

        public ushort Bombcapacity
        {
            get
            {
                return _bombcapacity;
            }

            set
            {
                _bombcapacity = value;
            }
        }
    }
    {
    privatr
}
