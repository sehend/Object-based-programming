﻿using System;

namespace Ornek1
{
    class Kutu
    {
        //boyutlar cm cinsindendir.
        private UInt16 length;
        private UInt16 width;
        //ağırlık birimi gram cinsindendir.
        private UInt16 weight;
        private string color;
        private string material;
        private bool breakable;

        public Kutu()
        {

        }
    }
}
