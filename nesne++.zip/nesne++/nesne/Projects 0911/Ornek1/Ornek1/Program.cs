﻿using System;

namespace Ornek1
{
    class Program
    {
        static void Main(string[] args)
        {
            Kutu kutu1 = new Kutu();
            Kutu kutu2 = new Kutu();
            //kutu1.color = "Kırmızı";
            //kutu2.color = "Mavi";
            //kutu1.height = 50;
            //kutu1.length = UInt16.Parse(Console.ReadLine());

            
            
        }
    }
}
