﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class kutu
    {

        public UInt16 length;
        public UInt16 height;
        public UInt16 width;

        public UInt16 weight;

        public string color;
        public string metarial;
        public bool breakable;
    }
}
