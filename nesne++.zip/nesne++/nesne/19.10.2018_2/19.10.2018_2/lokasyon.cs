﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19._10._2018_2
{
    public class lokasyon
    {
     
        public int x, y, z;
        
        public lokasyon(int a,int b, int c)
        {
            x = a;
            y = b;
            z = c;
            Console.WriteLine("x:" + x);
            Console.WriteLine("y:" + y);
            Console.WriteLine("z:" + z);

        }

       
    }
}
