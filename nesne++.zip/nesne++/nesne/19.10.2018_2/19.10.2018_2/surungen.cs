﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19._10._2018_2
{
   public class surungen:Animal
    {
        
        public void goster()
        {
            
        }
        
    }
}
