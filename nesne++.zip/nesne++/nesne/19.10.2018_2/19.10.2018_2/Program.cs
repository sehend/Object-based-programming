﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19._10._2018_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal hayvan = new Animal();
            //lokasyon locc = new lokasyon();


            hayvan.Move();
           
            // Animal h1= new Animal(Console.ReadLine(), Convert.ToUInt32( Console.ReadLine()), Convert.ToUInt32(Console.ReadLine()), Convert.ToUInt32(Console.ReadLine()), Animal.gender.male);
            Console.ReadKey();
        }
    }
}
