﻿using System;

namespace Inheritance
{
    public class Lokasyon
    {
        public int x;
        public int y;
        public int z;
        public Lokasyon() { }
        public Lokasyon(int X, int Y, int Z)
        {
            x = X;
            y = Y;
            z = Z;
        }
    }
}
