#include<stdio.h>
#include<stdlib.h>

int isPrime(int);
 
int main()
{
	int num,prime;
	printf("Pozitif bir sayi girin: ");
	scanf("%d",&num);
    prime = isPrime(num);
   if(prime==1)
        printf("%d asal bir sayidir.",num);
   else
      printf("%d asal bir sayi degildir.",num);

   system("pause");
   return 0;
}
 
int isPrime(int num)
{
	static int i=2;
    if(i<=num/2)
	{
		if(num%i==0)
			return 0;
         else
		 {
             i++;
             isPrime(num);
         }
    }
    return 1;
}