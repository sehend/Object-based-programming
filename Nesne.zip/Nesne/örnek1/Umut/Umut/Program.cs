﻿using System;

namespace Umut
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 3;

            switch (a)
            {
                case 1:
                    //code
                    break;
                case 2:
                    //code
                    break;
                //.
                //.
                //.
                default:
                    //code;
                    break;
            }
        }
    }
}
