﻿using System;

namespace Cansu
{
    class Program
    {
        static void Main(string[] args)
        {
            //while (false)
            //{

            //}

            //do
            //{

            //} while (false);
            //int sayac = 1;

            //for (int i = 100; i >= 28; i-=3)
            //{
            //    Console.WriteLine("{0}",sayac++);
            //}
            //Console.ReadLine();

            foreach (var item in collection)
            {

            }
        }
    }
}
