

/* Definition of perfect number or What is perfect number? 
 
Perfect number is a positive number which sum of all positive 
divisors excluding that number is equal to that number. 
For example 6 is perfect number since divisor of 6 are 1, 2 and 3.  
Sum of its divisor is
 
1 + 2+ 3 =6
 
Note: 6 is the smallest perfect number. 

Next perfect number is 28 since 1+ 2 + 4 + 7 + 14 = 28
 
Some more perfect numbers: 496, 8128  */


#include<stdio.h>
#include<stdlib.h>
 //1. C program to check perfect number

void find(int);

int main()
{
	int n,i=1,sum=0;
	printf("Bir sayi girin: ");
	scanf("%d",&n);

	find(n);

	system("pause"); 
	return 0;
}

void find(int x)
{
	int i=1,sum=0;

	while(i<x)
	{
      if(x%i==0)
           sum=sum+i;
          i++;
	}

	if(sum==x)
      printf("%d mukemmel bir sayidir.",i);
	else
      printf("%d mukemmel bir sayi degildir.",i);
}

