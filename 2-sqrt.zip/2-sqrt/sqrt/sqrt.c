#include <stdio.h>
#include <stdlib.h>
#include <math.h>


double squareroot(double);

int main(void)
{
	double number;

	printf("Bir sayi girin: ");
	scanf("%lf", &number);

	printf("%lf Sayisinin karekoku : %lf   \n", number, squareroot(number));


	system("pause");
	return (0);
}

double squareroot(double x)
{
	x=sqrt(x);

	return (x);
}
